#include "matriz.h"

int sumatoria(int m[][4], int* updiagonalp, int* dise, int* updiagonalincluida, int* underdiagonal)
{
    int i; j;

    for (i = 1; i <= 4; i++)
    {
        for (j = 1; j <= 4; j++)
        {
            if


        }
    }

}
