#ifndef MATRIZ_H_INCLUDED
#define MATRIZ_H_INCLUDED
#include <stdio.h>


int sumatoria (int m[][4], int* updiagonalp, int* dise, int* updiagonalincluida, int* underdiagonal);



#endif // MATRIZ_H_INCLUDED
